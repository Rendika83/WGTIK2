#include "CSLL.h"
int main()
{
    ListLagu L;
    address pLagu;
    string posisi,artis,judul,genre;
    int playtime, cnt;
    infotype data;

    create_List(L);
    cnt = 0;

    while(cnt < 7){
        cout<<"Artis: ";
        cin>>artis;
        cout<<endl;
        data.artis = artis;

        cout<<"Judul: ";
        cin>>judul;
        cout<<endl;
        data.judul = judul;

        cout<<"Genre: ";
        cin>>genre;
        cout<<endl;
        data.genre = genre;

        cout<<"playtime: ";
        cin>>playtime;
        cout<<endl;
        data.playtime = playtime;

        cout<<"Posisi: ";
        cin>>posisi;
        cout<<endl;

        createElemen(data,pLagu);
        tambahLagu(L,pLagu,posisi);

        cnt+=1;
    };
    showSemuaLagu(L);
    cout<<"--------------"<<endl;
    cout<<"LAGU PALING BANYAK DI PUTAR"<<endl;
    cout<<"--------------"<<endl;
    showMostPlay(L);

    resetPlayList(L);
    cout<<endl;
    showSemuaLagu(L);


    return 0;
}
