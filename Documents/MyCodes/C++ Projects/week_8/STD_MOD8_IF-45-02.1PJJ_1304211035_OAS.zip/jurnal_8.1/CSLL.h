#ifndef CSLL_H_INCLUDED
#define CSLL_H_INCLUDED

#include <iostream>
using namespace std;

#define nil NULL
#define info(P) (P)->info
#define next(P) (P)->next
#define first(L) ((L).first)

struct infotype {
    string artis;
    string judul;
    string genre;
    int playtime;
};

typedef struct element *address;

struct element {
    infotype info;
    address next;
};

struct ListLagu{
    address first;
};


void create_List(ListLagu &L);
void createElemen(infotype laguBaru, address &pLagu);
void insertFirst(ListLagu &L, address pLagu);
void insertLast(ListLagu &L, address pLagu);
void deleteFirst(ListLagu &L, address &pLagu);
void deleteLast(ListLagu &L, address &pLagu);
void showSemuaLagu(ListLagu L);
address createl(infotype laguBaru);

//Jurnal
void tambahLagu(ListLagu &L, address pLagu, string posisi);
void showMostPlay(ListLagu L); //1304211035
address cariLagu(ListLagu L, string artis, string judul);
void resetPlayList(ListLagu &L);

#endif // CSLL_H_INCLUDED

